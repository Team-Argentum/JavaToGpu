# OpenCL Vendor Validation Snapshot

- Requested vendor lane: `amd`
- Runner: `DESKTOP-23JNNV9 Windows`
- Git ref: `feat/large_update`
- Git SHA: `e69cc6552a6ddf39b74031788cfd64c2bdd419ab`

## Validation Buckets

- `atomicsCompileTest`: `passed` at `2026-07-10T10:09:02.464088400Z`
- `benchmarkTest`: `passed` at `2026-07-10T10:08:23.831522100Z`
- `compileOnlyTest`: `passed` at `2026-07-10T10:09:30.471943800Z`
- `imageOpenClTest`: `passed` at `2026-07-10T10:09:49.308387200Z`
- `integrationOpenClSmokeTest`: `passed` at `2026-07-10T10:08:46.125173800Z`
- `localMemoryTest`: `passed` at `2026-07-10T10:09:52.621244600Z`
- `openClIrGpuSourceReviewTest`: `passed` at `2026-07-10T10:08:47.531097100Z`
- `openClLongRunningStabilityTest`: `passed` at `2026-07-10T10:09:00.389617200Z`
- `openClWorkloadValidationTest`: `passed` at `2026-07-10T10:10:44.547280100Z`
- `performanceStressTest`: `passed` at `2026-07-10T10:10:03.259249Z`
- `runtimeOpenClTest`: `passed` at `2026-07-10T10:10:31.189426Z`
- `structAbiTest`: `passed` at `2026-07-10T10:10:39.059886800Z`
- Registry file: `C:\actions-runner\_work\JavaToGpu\JavaToGpu\processor\build\reports\opencl\bucket-status.properties`

## Serious Workloads

- Status: `passed`
- Completed at (UTC): `2026-07-10T10:10:44.457337400Z`
- Perlin workload: `passed`
- Packed/blob workload: `passed`
- Packed numeric workload: `passed`
- Synthetic 3D packed-grid workload: `passed`
- Image workload: `passed`
- Summary file: `C:\actions-runner\_work\JavaToGpu\JavaToGpu\processor\build\reports\opencl\workload-summary.properties`

## IrGpu Source Review

- Status: `passed`
- Review ready: `true`
- Source selection: `irgpu`
- Optimization profile: `source-reconstruction-review`
- Production source switching: `false`
- Scope: `opt-in-irgpu-source-review`
- Kernel count: `1`
- Kernel `0`: name=`gpu_irgpu_entry`, status=`passed`, resource=`inline://integration/simple-irgpu-source-kernel.cl`, irGpuResource=`javatogpu/runtime/opencl/integration/simple-irgpu-source-kernel.irgpu.properties`
- Diagnostic: `opt-in IrGpu source review lane does not alter production workload gate`
- Review file: `C:\actions-runner\_work\JavaToGpu\JavaToGpu\processor\build\reports\opencl\irgpu-source-review.properties`

## Controlled Production Source Switching

- Status: `not recorded`
- Validation file: `C:\actions-runner\_work\JavaToGpu\JavaToGpu\processor\build\reports\opencl\production-source-switching-validation.properties`

## Long-Running Stability Bucket

- Status: `passed`
- Completed at (UTC): `2026-07-10T10:09:00.305800400Z`
- Iterations: `150`
- Invocation count: `600`
- Compile count: `4`
- Compile cache hits: `596`
- Session creation count: `1`
- Device buffer creation count: `1050`
- Summary file: `C:\actions-runner\_work\JavaToGpu\JavaToGpu\processor\build\reports\opencl\long-running-summary.properties`

## Backend Source Promotion Contract Fixture

- Status: `review-ready`
- Review ready: `true`
- Source parity matched: `true`
- Runtime equivalence passed: `true`
- Scope: `synthetic contract fixture only; not production workload promotion`
- Gate file: `C:\actions-runner\_work\JavaToGpu\JavaToGpu\processor\build\reports\opencl\backend-source-promotion-gate.properties`

## Backend Source Promotion Workload Gate

- Status: `blocked`
- Review ready: `false`
- Gate status: `review-ready`
- Source parity matched: `true`
- Runtime equivalence passed: `true`
- Real workload evidence: `runtime-snapshot`
- Production promotion operator accepted: `0/5`, all=`false`
- Source switching decisions: `compile-descriptor-source=5`
- Blocker families: `reconstruction=5`
- Kernel evidence count: `5`
- Kernel `0`: `javatogpu/sample/PerlinWorkload/kernel.cl`, status=`review-ready`, parity=`true`, runtimeEquivalence=`true`, sourceSwitching=`compile-descriptor-source`, operatorAccepted=`false`, runtimeIr=`original`, productionMutation=`false`, sourceReady=`true`, i3=`review-ready`
- Kernel `0` source switching: status=`descriptor-default`, profile=`off`, sourcePromotionFirstBlocker=`none`, operatorAccepted=`false`, first=`descriptor source remains selected because opencl.sourceSelection did not request IrGpu source`
- Kernel `0` runtime IR handoff: stage=`original`, transformed=`false`, rollback=`false`, rejected=`false`, fallback=`none`, first=`optimized IrGpu is a pass-through artifact and remains selected for backend lowering`
- Kernel `0` production mutation safety: enabled=`false`, gate=`not-requested`, profileRequested=`false`, first=`runtime IR participates in diagnostics, but production mutation is disabled because no production profile was requested`
- Kernel `0` I3 readiness: status=`review-ready`, sourcePromotion=`review-ready`, sourceReady=`true`, optimizerGate=`not-requested`, productionMutation=`false`, first=`I3 source pipeline is review-ready, but production mutation remains disabled until production gates are accepted`
- Kernel `0` runtime optimizer drift: passes=`0`, applied=`0`, rolledBack=`0`, failed=`0`, proof=`0`, acceptedProof=`0`, blockingProof=`0`, optimizerFamilies=`0`, promotionReadyFamilies=`0`, selected=`original`, fallback=`none`, gate=`not-requested`
- Kernel `0` diagnostics: `1`; first=`backend source reconstruction is ready for promotion review`
- Kernel blocker families: `reconstruction=1`
- Kernel `1`: `javatogpu/sample/PackedBlobWorkload/kernel.cl`, status=`review-ready`, parity=`true`, runtimeEquivalence=`true`, sourceSwitching=`compile-descriptor-source`, operatorAccepted=`false`, runtimeIr=`original`, productionMutation=`false`, sourceReady=`true`, i3=`review-ready`
- Kernel `1` source switching: status=`descriptor-default`, profile=`off`, sourcePromotionFirstBlocker=`none`, operatorAccepted=`false`, first=`descriptor source remains selected because opencl.sourceSelection did not request IrGpu source`
- Kernel `1` runtime IR handoff: stage=`original`, transformed=`false`, rollback=`false`, rejected=`false`, fallback=`none`, first=`optimized IrGpu is a pass-through artifact and remains selected for backend lowering`
- Kernel `1` production mutation safety: enabled=`false`, gate=`not-requested`, profileRequested=`false`, first=`runtime IR participates in diagnostics, but production mutation is disabled because no production profile was requested`
- Kernel `1` I3 readiness: status=`review-ready`, sourcePromotion=`review-ready`, sourceReady=`true`, optimizerGate=`not-requested`, productionMutation=`false`, first=`I3 source pipeline is review-ready, but production mutation remains disabled until production gates are accepted`
- Kernel `1` runtime optimizer drift: passes=`0`, applied=`0`, rolledBack=`0`, failed=`0`, proof=`0`, acceptedProof=`0`, blockingProof=`0`, optimizerFamilies=`0`, promotionReadyFamilies=`0`, selected=`original`, fallback=`none`, gate=`not-requested`
- Kernel `1` diagnostics: `1`; first=`backend source reconstruction is ready for promotion review`
- Kernel blocker families: `reconstruction=1`
- Kernel `2`: `javatogpu/sample/PackedNumericWorkload/kernel.cl`, status=`review-ready`, parity=`true`, runtimeEquivalence=`true`, sourceSwitching=`compile-descriptor-source`, operatorAccepted=`false`, runtimeIr=`original`, productionMutation=`false`, sourceReady=`true`, i3=`review-ready`
- Kernel `2` source switching: status=`descriptor-default`, profile=`off`, sourcePromotionFirstBlocker=`none`, operatorAccepted=`false`, first=`descriptor source remains selected because opencl.sourceSelection did not request IrGpu source`
- Kernel `2` runtime IR handoff: stage=`original`, transformed=`false`, rollback=`false`, rejected=`false`, fallback=`none`, first=`optimized IrGpu is a pass-through artifact and remains selected for backend lowering`
- Kernel `2` production mutation safety: enabled=`false`, gate=`not-requested`, profileRequested=`false`, first=`runtime IR participates in diagnostics, but production mutation is disabled because no production profile was requested`
- Kernel `2` I3 readiness: status=`review-ready`, sourcePromotion=`review-ready`, sourceReady=`true`, optimizerGate=`not-requested`, productionMutation=`false`, first=`I3 source pipeline is review-ready, but production mutation remains disabled until production gates are accepted`
- Kernel `2` runtime optimizer drift: passes=`0`, applied=`0`, rolledBack=`0`, failed=`0`, proof=`0`, acceptedProof=`0`, blockingProof=`0`, optimizerFamilies=`0`, promotionReadyFamilies=`0`, selected=`original`, fallback=`none`, gate=`not-requested`
- Kernel `2` diagnostics: `1`; first=`backend source reconstruction is ready for promotion review`
- Kernel blocker families: `reconstruction=1`
- Kernel `3`: `javatogpu/sample/Synthetic3DPackedGridWorkload/kernel.cl`, status=`review-ready`, parity=`true`, runtimeEquivalence=`true`, sourceSwitching=`compile-descriptor-source`, operatorAccepted=`false`, runtimeIr=`original`, productionMutation=`false`, sourceReady=`true`, i3=`review-ready`
- Kernel `3` source switching: status=`descriptor-default`, profile=`off`, sourcePromotionFirstBlocker=`none`, operatorAccepted=`false`, first=`descriptor source remains selected because opencl.sourceSelection did not request IrGpu source`
- Kernel `3` runtime IR handoff: stage=`original`, transformed=`false`, rollback=`false`, rejected=`false`, fallback=`none`, first=`optimized IrGpu is a pass-through artifact and remains selected for backend lowering`
- Kernel `3` production mutation safety: enabled=`false`, gate=`not-requested`, profileRequested=`false`, first=`runtime IR participates in diagnostics, but production mutation is disabled because no production profile was requested`
- Kernel `3` I3 readiness: status=`review-ready`, sourcePromotion=`review-ready`, sourceReady=`true`, optimizerGate=`not-requested`, productionMutation=`false`, first=`I3 source pipeline is review-ready, but production mutation remains disabled until production gates are accepted`
- Kernel `3` runtime optimizer drift: passes=`0`, applied=`0`, rolledBack=`0`, failed=`0`, proof=`0`, acceptedProof=`0`, blockingProof=`0`, optimizerFamilies=`0`, promotionReadyFamilies=`0`, selected=`original`, fallback=`none`, gate=`not-requested`
- Kernel `3` diagnostics: `1`; first=`backend source reconstruction is ready for promotion review`
- Kernel blocker families: `reconstruction=1`
- Kernel `4`: `inline://integration/image-kernel.cl`, status=`review-ready`, parity=`true`, runtimeEquivalence=`true`, sourceSwitching=`compile-descriptor-source`, operatorAccepted=`false`, runtimeIr=`original`, productionMutation=`false`, sourceReady=`true`, i3=`review-ready`
- Kernel `4` source switching: status=`descriptor-default`, profile=`off`, sourcePromotionFirstBlocker=`none`, operatorAccepted=`false`, first=`descriptor source remains selected because opencl.sourceSelection did not request IrGpu source`
- Kernel `4` runtime IR handoff: stage=`original`, transformed=`false`, rollback=`false`, rejected=`false`, fallback=`none`, first=`optimized IrGpu is a pass-through artifact and remains selected for backend lowering`
- Kernel `4` production mutation safety: enabled=`false`, gate=`not-requested`, profileRequested=`false`, first=`runtime IR participates in diagnostics, but production mutation is disabled because no production profile was requested`
- Kernel `4` I3 readiness: status=`review-ready`, sourcePromotion=`review-ready`, sourceReady=`true`, optimizerGate=`not-requested`, productionMutation=`false`, first=`I3 source pipeline is review-ready, but production mutation remains disabled until production gates are accepted`
- Kernel `4` runtime optimizer drift: passes=`0`, applied=`0`, rolledBack=`0`, failed=`0`, proof=`0`, acceptedProof=`0`, blockingProof=`0`, optimizerFamilies=`0`, promotionReadyFamilies=`0`, selected=`original`, fallback=`none`, gate=`not-requested`
- Kernel `4` diagnostics: `1`; first=`backend source reconstruction is ready for promotion review`
- Kernel blocker families: `reconstruction=1`
- Reason: `one or more workload kernels reached review-ready, but production source switching is disabled`
- Production source switching: `disabled`
- Scope: `real workload promotion gate; fail-closed until workload evidence is wired`
- Gate file: `C:\actions-runner\_work\JavaToGpu\JavaToGpu\processor\build\reports\opencl\backend-source-promotion-workload-gate.properties`

## Production Promotion Explainability

- Status: `blocked`
- Contract: `valid`
- Decision mode: `review-ready`
- Production source switching allowed: `false`
- Production source switching enabled: `false`
- Production mutation allowed: `false`
- Production mutation enabled: `false`
- Controlled source switching smoke: `not-recorded`
- Controlled source switching kernels: `0`
- Controlled real workload coverage: `0/5`
- Controlled real workload coverage all: `false`
- Production readiness checklist: `6 ready / 3 blocked`
- Production readiness checklist all: `false`
- First readiness blocker: `controlled-source-switching-covered`
- Kernel count: `5`
- I3 review-ready kernels: `5`
- I3 blocked kernels: `0`
- Optimizer families: `0`
- Optimizer promotion-ready families: `0`
- Optimizer payload-complete families: `0`
- Optimizer payload complete all: `false`
- Blocker count: `5`
- First blocker: `production-source-switching-disabled`
- Diagnostic: `production promotion remains blocked: first=production-source-switching-disabled, i3ReviewReady=5, i3Blocked=0`
- Explainability file: `C:\actions-runner\_work\JavaToGpu\JavaToGpu\processor\build\reports\opencl\production-promotion-explainability.properties`

# OpenCL Validation Report

Generated at (UTC): 2026-07-10T10:11:10.072384200Z

## Runtime

- Backend: `OpenCL`
- Cache mode: `INSTANCE`
- Device label: `AMD Accelerated Parallel Processing / gfx1101`
- Vendor: `Advanced Micro Devices, Inc.`
- Driver version: `3679.0 (PAL,LC)`
- Device version: `OpenCL 2.0 AMD-APP (3679.0)`
- Platform: `AMD Accelerated Parallel Processing`
- Platform version: `OpenCL 2.1 AMD-APP (3679.0)`
- Local memory bytes: `32768`
- Max work-group size: `256`

## Features

- Double precision: `yes`
- Images: `yes`
- 3D image writes: `yes`

## Production Promotion Artifacts

- Backend target: `OPENCL`
- Complete support: `yes`
- Supported artifact count: `12`
- Missing artifact count: `0`
- Supported artifacts: `i3-readiness-summary.properties, backend-source-promotion-gate.properties, backend-source-switching-decision.properties, backend-source-promotion-workload-gate.properties, backend-source-promotion-workload-summary.properties, production-promotion-explainability.properties, production-promotion-explainability-summary.properties, backend-promotion-artifact-support.properties, runtime-ir-handoff.properties, runtime-production-mutation-safety.properties, runtime-optimizer-drift.properties, runtime-optimizer-family-equivalence-payload.properties`
- Missing artifacts: `none`

## Counters

- Invocation count: `0`
- Compile count: `0`
- Compile cache hits: `0`
- Session creation count: `1`
- Device buffer creation count: `0`
