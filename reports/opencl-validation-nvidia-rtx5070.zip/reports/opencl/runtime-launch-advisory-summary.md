## Kernel Launch Advisories

- Status: `recorded`
- Kernel count: `5`
- Aligned: `1`
- Non-preferred multiple: `1`
- Driver-selected: `3`
- Unavailable: `0`
- Missing: `0`
- Blocking: `0`

| Kernel resource | Status | Local shape | Size | Kernel max | Preferred | Matched | Blocking |
| --- | --- | --- | ---: | ---: | ---: | --- | --- |
| `javatogpu/sample/PerlinWorkload/kernel.cl` | `non-preferred-multiple` | `48` | `48` | `256` | `32` | `false` | `false` |
| `javatogpu/sample/PackedBlobWorkload/kernel.cl` | `driver-selected` | `driver-selected` | `0` | `256` | `32` | `false` | `false` |
| `javatogpu/sample/PackedNumericWorkload/kernel.cl` | `driver-selected` | `driver-selected` | `0` | `256` | `32` | `false` | `false` |
| `javatogpu/sample/Synthetic3DPackedGridWorkload/kernel.cl` | `aligned` | `8x8x1` | `64` | `256` | `32` | `true` | `false` |
| `inline://integration/image-kernel.cl` | `driver-selected` | `driver-selected` | `0` | `256` | `32` | `false` | `false` |

## Kernel Launch Advisory Drift

- Status: `regressed`
- Regression: `true`
- Current counts: `kernels=5, aligned=1, nonPreferred=1, driverSelected=3, unavailable=0, missing=0, blocking=0`
- Previous generated at (UTC): `2026-07-10T15:04:17.340909400Z`
- Previous driver: `595.97`
- Previous counts: `kernels=5, aligned=1, nonPreferred=1, driverSelected=3, unavailable=0, missing=0, blocking=0`
- Delta: `kernels=+0, aligned=+0, nonPreferred=+0, driverSelected=+0, unavailable=+0, missing=+0, blocking=+0`
- Per-kernel comparison: `available`
- Per-kernel changes: `1`
- Per-kernel regressions: `1`
- Per-kernel improvements: `0`
- Diagnostic: `per-kernel launch advisory regressed for javatogpu/sample/PerlinWorkload/kernel.cl`

| Kernel resource | Classification | Status | Kernel max | Preferred | Diagnostic |
| --- | --- | --- | ---: | ---: | --- |
| `javatogpu/sample/PerlinWorkload/kernel.cl` | `regressed` | `non-preferred-multiple` | `512 -> 256` | `32` | `kernel max 512 -> 256` |

