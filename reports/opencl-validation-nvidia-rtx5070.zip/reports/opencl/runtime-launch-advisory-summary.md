## Kernel Launch Advisories

- Status: `recorded`
- Kernel count: `5`
- Aligned: `1`
- Non-preferred multiple: `1`
- Driver-selected: `3`
- Unavailable: `0`
- Missing: `0`
- Blocking: `0`

| Kernel resource | Status | Local shape | Size | Kernel max | Preferred | Matched | Blocking |
| --- | --- | --- | ---: | ---: | ---: | --- | --- |
| `javatogpu/sample/PerlinWorkload/kernel.cl` | `non-preferred-multiple` | `48` | `48` | `256` | `32` | `false` | `false` |
| `javatogpu/sample/PackedBlobWorkload/kernel.cl` | `driver-selected` | `driver-selected` | `0` | `256` | `32` | `false` | `false` |
| `javatogpu/sample/PackedNumericWorkload/kernel.cl` | `driver-selected` | `driver-selected` | `0` | `256` | `32` | `false` | `false` |
| `javatogpu/sample/Synthetic3DPackedGridWorkload/kernel.cl` | `aligned` | `8x8x1` | `64` | `256` | `32` | `true` | `false` |
| `inline://integration/image-kernel.cl` | `driver-selected` | `driver-selected` | `0` | `256` | `32` | `false` | `false` |

## Kernel Launch Advisory Drift

- Status: `stable`
- Regression: `false`
- Current counts: `kernels=5, aligned=1, nonPreferred=1, driverSelected=3, unavailable=0, missing=0, blocking=0`
- Previous generated at (UTC): `2026-07-10T13:50:12.204707400Z`
- Previous driver: `595.97`
- Previous counts: `kernels=5, aligned=1, nonPreferred=1, driverSelected=3, unavailable=0, missing=0, blocking=0`
- Delta: `kernels=+0, aligned=+0, nonPreferred=+0, driverSelected=+0, unavailable=+0, missing=+0, blocking=+0`
- Diagnostic: `launch-advisory counts are unchanged`

