# OpenCL Vendor Validation Snapshot

- Requested vendor lane: `nvidia`
- Runner: `DESKTOP-GF35FAR Windows`
- Git ref: `feat/large_update`
- Git SHA: `e4d3bf21d456c906af806c1c61bfc3f9efd99815`

## Validation Buckets

- `atomicsCompileTest`: `passed` at `2026-07-10T14:07:55.995647300Z`
- `benchmarkTest`: `passed` at `2026-07-10T14:07:27.728207900Z`
- `compileOnlyTest`: `passed` at `2026-07-10T14:08:11.157586300Z`
- `imageOpenClTest`: `passed` at `2026-07-10T14:08:26.831364200Z`
- `integrationOpenClSmokeTest`: `passed` at `2026-07-10T14:07:44.865839900Z`
- `localMemoryTest`: `passed` at `2026-07-10T14:08:29.167449300Z`
- `openClIrGpuSourceReviewTest`: `passed` at `2026-07-10T14:07:45.754934300Z`
- `openClLongRunningStabilityTest`: `passed` at `2026-07-10T14:07:51.684623200Z`
- `openClProductionSourceSwitchingValidationTest`: `passed` at `2026-07-10T14:07:54.735301300Z`
- `openClWorkloadValidationTest`: `passed` at `2026-07-10T14:09:05.367816500Z`
- `performanceStressTest`: `passed` at `2026-07-10T14:08:34.161138800Z`
- `runtimeOpenClTest`: `passed` at `2026-07-10T14:08:56.416365400Z`
- `structAbiTest`: `passed` at `2026-07-10T14:09:01.830279600Z`
- Registry file: `C:\actions-runner\_work\JavaToGpu\JavaToGpu\processor\build\reports\opencl\bucket-status.properties`

## Serious Workloads

- Status: `passed`
- Completed at (UTC): `2026-07-10T14:09:05.308404900Z`
- Perlin workload: `passed`
- Packed/blob workload: `passed`
- Packed numeric workload: `passed`
- Synthetic 3D packed-grid workload: `passed`
- Image workload: `passed`
- Summary file: `C:\actions-runner\_work\JavaToGpu\JavaToGpu\processor\build\reports\opencl\workload-summary.properties`

## Kernel Launch Advisories

- Status: `recorded`
- Kernel count: `5`
- Aligned: `1`
- Non-preferred multiple: `1`
- Driver-selected: `3`
- Unavailable: `0`
- Missing: `0`
- Blocking: `0`

| Kernel resource | Status | Local shape | Size | Kernel max | Preferred | Matched | Blocking |
| --- | --- | --- | ---: | ---: | ---: | --- | --- |
| `javatogpu/sample/PerlinWorkload/kernel.cl` | `non-preferred-multiple` | `48` | `48` | `256` | `32` | `false` | `false` |
| `javatogpu/sample/PackedBlobWorkload/kernel.cl` | `driver-selected` | `driver-selected` | `0` | `256` | `32` | `false` | `false` |
| `javatogpu/sample/PackedNumericWorkload/kernel.cl` | `driver-selected` | `driver-selected` | `0` | `256` | `32` | `false` | `false` |
| `javatogpu/sample/Synthetic3DPackedGridWorkload/kernel.cl` | `aligned` | `8x8x1` | `64` | `256` | `32` | `true` | `false` |
| `inline://integration/image-kernel.cl` | `driver-selected` | `driver-selected` | `0` | `256` | `32` | `false` | `false` |

## Kernel Launch Advisory Drift

- Status: `stable`
- Regression: `false`
- Current counts: `kernels=5, aligned=1, nonPreferred=1, driverSelected=3, unavailable=0, missing=0, blocking=0`
- Previous generated at (UTC): `2026-07-10T13:50:12.204707400Z`
- Previous driver: `595.97`
- Previous counts: `kernels=5, aligned=1, nonPreferred=1, driverSelected=3, unavailable=0, missing=0, blocking=0`
- Delta: `kernels=+0, aligned=+0, nonPreferred=+0, driverSelected=+0, unavailable=+0, missing=+0, blocking=+0`
- Diagnostic: `launch-advisory counts are unchanged`

## IrGpu Source Review

- Status: `passed`
- Review ready: `true`
- Source selection: `irgpu`
- Optimization profile: `source-reconstruction-review`
- Production source switching: `false`
- Scope: `opt-in-irgpu-source-review`
- Kernel count: `1`
- Kernel `0`: name=`gpu_irgpu_entry`, status=`passed`, resource=`inline://integration/simple-irgpu-source-kernel.cl`, irGpuResource=`javatogpu/runtime/opencl/integration/simple-irgpu-source-kernel.irgpu.properties`
- Diagnostic: `opt-in IrGpu source review lane does not alter production workload gate`
- Review file: `C:\actions-runner\_work\JavaToGpu\JavaToGpu\processor\build\reports\opencl\irgpu-source-review.properties`

## Controlled Production Source Switching

- Status: `passed`
- Review ready: `true`
- Source selection: `irgpu`
- Optimization profile: `vendor-tuned`
- Production source switching: `enabled`
- Production decision mode: `production-enabled`
- Scope: `controlled-production-source-switching-smoke`
- Kernel count: `7`
- Kernel `0`: name=`gpu_irgpu_entry`, status=`passed`, resource=`inline://integration/simple-irgpu-source-kernel.cl`, irGpuResource=`javatogpu/runtime/opencl/integration/simple-irgpu-source-kernel.irgpu.properties`
- Kernel `1`: name=`gpu_image_entry`, status=`passed`, resource=`inline://integration/image-kernel.cl`, irGpuResource=`javatogpu/runtime/opencl/integration/image-kernel.irgpu.properties`
- Kernel `2`: name=`gpu_dual_buffer_int_entry`, status=`passed`, resource=`inline://integration/dual-buffer-int-kernel.cl`, irGpuResource=`javatogpu/runtime/opencl/integration/dual-buffer-int-kernel.irgpu.properties`
- Kernel `3`: name=`gpu_kernel`, status=`passed`, resource=`javatogpu/sample/PerlinWorkload/kernel.cl`, irGpuResource=`javatogpu/sample/PerlinWorkload/kernel.irgpu.properties`
- Kernel `4`: name=`gpu_kernel`, status=`passed`, resource=`javatogpu/sample/PackedBlobWorkload/kernel.cl`, irGpuResource=`javatogpu/sample/PackedBlobWorkload/kernel.irgpu.properties`
- Kernel `5`: name=`gpu_kernel`, status=`passed`, resource=`javatogpu/sample/PackedNumericWorkload/kernel.cl`, irGpuResource=`javatogpu/sample/PackedNumericWorkload/kernel.irgpu.properties`
- Kernel `6`: name=`gpu_kernel`, status=`passed`, resource=`javatogpu/sample/Synthetic3DPackedGridWorkload/kernel.cl`, irGpuResource=`javatogpu/sample/Synthetic3DPackedGridWorkload/kernel.irgpu.properties`
- Diagnostic: `controlled production source-switching lane uses explicit production-enabled evidence only`
- Validation file: `C:\actions-runner\_work\JavaToGpu\JavaToGpu\processor\build\reports\opencl\production-source-switching-validation.properties`

## Long-Running Stability Bucket

- Status: `passed`
- Completed at (UTC): `2026-07-10T14:07:51.575555200Z`
- Iterations: `150`
- Invocation count: `600`
- Compile count: `4`
- Compile cache hits: `596`
- Session creation count: `1`
- Device buffer creation count: `1050`
- Summary file: `C:\actions-runner\_work\JavaToGpu\JavaToGpu\processor\build\reports\opencl\long-running-summary.properties`

## Backend Source Promotion Contract Fixture

- Status: `review-ready`
- Review ready: `true`
- Source parity matched: `true`
- Runtime equivalence passed: `true`
- Scope: `synthetic contract fixture only; not production workload promotion`
- Gate file: `C:\actions-runner\_work\JavaToGpu\JavaToGpu\processor\build\reports\opencl\backend-source-promotion-gate.properties`

## Backend Source Promotion Workload Gate

- Status: `blocked`
- Review ready: `false`
- Gate status: `review-ready`
- Source parity matched: `true`
- Runtime equivalence passed: `true`
- Real workload evidence: `runtime-snapshot`
- Production promotion operator accepted: `0/5`, all=`false`
- Source switching decisions: `compile-descriptor-source=5`
- Blocker families: `reconstruction=5`
- Kernel evidence count: `5`
- Kernel `0`: `javatogpu/sample/PerlinWorkload/kernel.cl`, status=`review-ready`, parity=`true`, runtimeEquivalence=`true`, sourceSwitching=`compile-descriptor-source`, operatorAccepted=`false`, runtimeIr=`original`, productionMutation=`false`, sourceReady=`true`, i3=`review-ready`
- Kernel `0` source switching: status=`descriptor-default`, profile=`off`, sourcePromotionFirstBlocker=`none`, operatorAccepted=`false`, first=`descriptor source remains selected because opencl.sourceSelection did not request IrGpu source`
- Kernel `0` runtime IR handoff: stage=`original`, transformed=`false`, rollback=`false`, rejected=`false`, fallback=`none`, first=`optimized IrGpu is a pass-through artifact and remains selected for backend lowering`
- Kernel `0` production mutation safety: enabled=`false`, gate=`not-requested`, profileRequested=`false`, first=`runtime IR participates in diagnostics, but production mutation is disabled because no production profile was requested`
- Kernel `0` I3 readiness: status=`review-ready`, sourcePromotion=`review-ready`, sourceReady=`true`, optimizerGate=`not-requested`, productionMutation=`false`, first=`I3 source pipeline is review-ready, but production mutation remains disabled until production gates are accepted`
- Kernel `0` runtime optimizer drift: passes=`0`, applied=`0`, rolledBack=`0`, failed=`0`, proof=`0`, acceptedProof=`0`, blockingProof=`0`, optimizerFamilies=`0`, promotionReadyFamilies=`0`, selected=`original`, fallback=`none`, gate=`not-requested`
- Kernel `0` diagnostics: `1`; first=`backend source reconstruction is ready for promotion review`
- Kernel blocker families: `reconstruction=1`
- Kernel `1`: `javatogpu/sample/PackedBlobWorkload/kernel.cl`, status=`review-ready`, parity=`true`, runtimeEquivalence=`true`, sourceSwitching=`compile-descriptor-source`, operatorAccepted=`false`, runtimeIr=`original`, productionMutation=`false`, sourceReady=`true`, i3=`review-ready`
- Kernel `1` source switching: status=`descriptor-default`, profile=`off`, sourcePromotionFirstBlocker=`none`, operatorAccepted=`false`, first=`descriptor source remains selected because opencl.sourceSelection did not request IrGpu source`
- Kernel `1` runtime IR handoff: stage=`original`, transformed=`false`, rollback=`false`, rejected=`false`, fallback=`none`, first=`optimized IrGpu is a pass-through artifact and remains selected for backend lowering`
- Kernel `1` production mutation safety: enabled=`false`, gate=`not-requested`, profileRequested=`false`, first=`runtime IR participates in diagnostics, but production mutation is disabled because no production profile was requested`
- Kernel `1` I3 readiness: status=`review-ready`, sourcePromotion=`review-ready`, sourceReady=`true`, optimizerGate=`not-requested`, productionMutation=`false`, first=`I3 source pipeline is review-ready, but production mutation remains disabled until production gates are accepted`
- Kernel `1` runtime optimizer drift: passes=`0`, applied=`0`, rolledBack=`0`, failed=`0`, proof=`0`, acceptedProof=`0`, blockingProof=`0`, optimizerFamilies=`0`, promotionReadyFamilies=`0`, selected=`original`, fallback=`none`, gate=`not-requested`
- Kernel `1` diagnostics: `1`; first=`backend source reconstruction is ready for promotion review`
- Kernel blocker families: `reconstruction=1`
- Kernel `2`: `javatogpu/sample/PackedNumericWorkload/kernel.cl`, status=`review-ready`, parity=`true`, runtimeEquivalence=`true`, sourceSwitching=`compile-descriptor-source`, operatorAccepted=`false`, runtimeIr=`original`, productionMutation=`false`, sourceReady=`true`, i3=`review-ready`
- Kernel `2` source switching: status=`descriptor-default`, profile=`off`, sourcePromotionFirstBlocker=`none`, operatorAccepted=`false`, first=`descriptor source remains selected because opencl.sourceSelection did not request IrGpu source`
- Kernel `2` runtime IR handoff: stage=`original`, transformed=`false`, rollback=`false`, rejected=`false`, fallback=`none`, first=`optimized IrGpu is a pass-through artifact and remains selected for backend lowering`
- Kernel `2` production mutation safety: enabled=`false`, gate=`not-requested`, profileRequested=`false`, first=`runtime IR participates in diagnostics, but production mutation is disabled because no production profile was requested`
- Kernel `2` I3 readiness: status=`review-ready`, sourcePromotion=`review-ready`, sourceReady=`true`, optimizerGate=`not-requested`, productionMutation=`false`, first=`I3 source pipeline is review-ready, but production mutation remains disabled until production gates are accepted`
- Kernel `2` runtime optimizer drift: passes=`0`, applied=`0`, rolledBack=`0`, failed=`0`, proof=`0`, acceptedProof=`0`, blockingProof=`0`, optimizerFamilies=`0`, promotionReadyFamilies=`0`, selected=`original`, fallback=`none`, gate=`not-requested`
- Kernel `2` diagnostics: `1`; first=`backend source reconstruction is ready for promotion review`
- Kernel blocker families: `reconstruction=1`
- Kernel `3`: `javatogpu/sample/Synthetic3DPackedGridWorkload/kernel.cl`, status=`review-ready`, parity=`true`, runtimeEquivalence=`true`, sourceSwitching=`compile-descriptor-source`, operatorAccepted=`false`, runtimeIr=`original`, productionMutation=`false`, sourceReady=`true`, i3=`review-ready`
- Kernel `3` source switching: status=`descriptor-default`, profile=`off`, sourcePromotionFirstBlocker=`none`, operatorAccepted=`false`, first=`descriptor source remains selected because opencl.sourceSelection did not request IrGpu source`
- Kernel `3` runtime IR handoff: stage=`original`, transformed=`false`, rollback=`false`, rejected=`false`, fallback=`none`, first=`optimized IrGpu is a pass-through artifact and remains selected for backend lowering`
- Kernel `3` production mutation safety: enabled=`false`, gate=`not-requested`, profileRequested=`false`, first=`runtime IR participates in diagnostics, but production mutation is disabled because no production profile was requested`
- Kernel `3` I3 readiness: status=`review-ready`, sourcePromotion=`review-ready`, sourceReady=`true`, optimizerGate=`not-requested`, productionMutation=`false`, first=`I3 source pipeline is review-ready, but production mutation remains disabled until production gates are accepted`
- Kernel `3` runtime optimizer drift: passes=`0`, applied=`0`, rolledBack=`0`, failed=`0`, proof=`0`, acceptedProof=`0`, blockingProof=`0`, optimizerFamilies=`0`, promotionReadyFamilies=`0`, selected=`original`, fallback=`none`, gate=`not-requested`
- Kernel `3` diagnostics: `1`; first=`backend source reconstruction is ready for promotion review`
- Kernel blocker families: `reconstruction=1`
- Kernel `4`: `inline://integration/image-kernel.cl`, status=`review-ready`, parity=`true`, runtimeEquivalence=`true`, sourceSwitching=`compile-descriptor-source`, operatorAccepted=`false`, runtimeIr=`original`, productionMutation=`false`, sourceReady=`true`, i3=`review-ready`
- Kernel `4` source switching: status=`descriptor-default`, profile=`off`, sourcePromotionFirstBlocker=`none`, operatorAccepted=`false`, first=`descriptor source remains selected because opencl.sourceSelection did not request IrGpu source`
- Kernel `4` runtime IR handoff: stage=`original`, transformed=`false`, rollback=`false`, rejected=`false`, fallback=`none`, first=`optimized IrGpu is a pass-through artifact and remains selected for backend lowering`
- Kernel `4` production mutation safety: enabled=`false`, gate=`not-requested`, profileRequested=`false`, first=`runtime IR participates in diagnostics, but production mutation is disabled because no production profile was requested`
- Kernel `4` I3 readiness: status=`review-ready`, sourcePromotion=`review-ready`, sourceReady=`true`, optimizerGate=`not-requested`, productionMutation=`false`, first=`I3 source pipeline is review-ready, but production mutation remains disabled until production gates are accepted`
- Kernel `4` runtime optimizer drift: passes=`0`, applied=`0`, rolledBack=`0`, failed=`0`, proof=`0`, acceptedProof=`0`, blockingProof=`0`, optimizerFamilies=`0`, promotionReadyFamilies=`0`, selected=`original`, fallback=`none`, gate=`not-requested`
- Kernel `4` diagnostics: `1`; first=`backend source reconstruction is ready for promotion review`
- Kernel blocker families: `reconstruction=1`
- Reason: `one or more workload kernels reached review-ready, but production source switching is disabled`
- Production source switching: `disabled`
- Scope: `real workload promotion gate; fail-closed until workload evidence is wired`
- Gate file: `C:\actions-runner\_work\JavaToGpu\JavaToGpu\processor\build\reports\opencl\backend-source-promotion-workload-gate.properties`

## Production Promotion Explainability

- Status: `blocked`
- Contract: `valid`
- Decision mode: `review-ready`
- Production source switching allowed: `false`
- Production source switching enabled: `false`
- Production mutation allowed: `false`
- Production mutation enabled: `false`
- Controlled source switching smoke: `passed`
- Controlled source switching kernels: `7`
- Controlled real workload coverage: `5/5`
- Controlled real workload coverage all: `true`
- Production readiness checklist: `7 ready / 2 blocked`
- Production readiness checklist all: `false`
- First readiness blocker: `production-source-switching-enabled`
- Kernel count: `5`
- I3 review-ready kernels: `5`
- I3 blocked kernels: `0`
- Optimizer families: `0`
- Optimizer promotion-ready families: `0`
- Optimizer payload-complete families: `0`
- Optimizer payload complete all: `false`
- Blocker count: `5`
- First blocker: `production-source-switching-disabled`
- Diagnostic: `production promotion remains blocked: first=production-source-switching-disabled, i3ReviewReady=5, i3Blocked=0`
- Explainability file: `C:\actions-runner\_work\JavaToGpu\JavaToGpu\processor\build\reports\opencl\production-promotion-explainability.properties`

# OpenCL Validation Report

Generated at (UTC): 2026-07-10T14:09:39.702886400Z

## Runtime

- Backend: `OpenCL`
- Cache mode: `INSTANCE`
- Device label: `NVIDIA CUDA / NVIDIA GeForce RTX 5070`
- Vendor: `NVIDIA Corporation`
- Driver version: `595.97`
- Device version: `OpenCL 3.0 CUDA`
- Platform: `NVIDIA CUDA`
- Platform version: `OpenCL 3.0 CUDA 13.2.73`
- Local memory bytes: `49152`
- Max work-group size: `1024`

## Features

- Double precision: `yes`
- Images: `yes`
- 3D image writes: `yes`

## Production Promotion Artifacts

- Backend target: `OPENCL`
- Complete support: `yes`
- Supported artifact count: `12`
- Missing artifact count: `0`
- Supported artifacts: `i3-readiness-summary.properties, backend-source-promotion-gate.properties, backend-source-switching-decision.properties, backend-source-promotion-workload-gate.properties, backend-source-promotion-workload-summary.properties, production-promotion-explainability.properties, production-promotion-explainability-summary.properties, backend-promotion-artifact-support.properties, runtime-ir-handoff.properties, runtime-production-mutation-safety.properties, runtime-optimizer-drift.properties, runtime-optimizer-family-equivalence-payload.properties`
- Missing artifacts: `none`

## Counters

- Invocation count: `0`
- Compile count: `0`
- Compile cache hits: `0`
- Session creation count: `1`
- Device buffer creation count: `0`
